#!/bin/bash
# Put your command below to execute your program.
# Replace "./my-program" with the command that can execute your program.
# Remember to preserve " $@" at the end, which will be the program options we give you.


# requirement
# scikit learn 
# pandas

python3 ./src/main.py $@
